# CSI Meetpar Yesu Alayam — WhatsApp Automation Centre

Responsive starter website for desktop and mobile using GitHub Pages (no Netlify) and Supabase for shared member contacts and message logs.

## Included
- `index.html` — website dashboard
- `supabase/schema.sql` — database tables, indexes, Row Level Security (RLS), and starter policies
- `README.md` — setup instructions

## Setup
1. In Supabase, open the NEW project `csi-whatsapp-centre`.
2. Open **SQL Editor → New query**.
3. Open `supabase/schema.sql` from this ZIP in a text editor, copy all its contents, paste into SQL Editor, and click **Run**. Do not include Markdown backticks.
4. Confirm the query succeeds. RLS is enabled by this SQL; policies allow signed-in users to share this register.
5. Open **Project Settings → API Keys** and copy the **Project URL** and **Publishable key**. Never use a secret/service-role key in the browser.
6. In GitHub repository `csi-whatsapp-centre`, upload/replace `index.html` and upload the `supabase` folder at the repository root. Keep the folder name and structure. `README.md` may also be replaced with this one.
7. Ensure GitHub Pages is set to **Settings → Pages → Deploy from a branch → main → /(root)**.
8. Open the published site. Enter the Project URL and Publishable key, click **Connect project**, then create a user account. If email confirmation is enabled, confirm the email and sign in.
9. Use the same Supabase project and authorized accounts on each device to see the shared register.

## Test carefully
- First test with a contact and phone number you control.
- Only tick WhatsApp consent when the member has explicitly agreed.
- The Draft button opens a prefilled WhatsApp message. You must press Send yourself.
- Automatic WhatsApp delivery is NOT included/enabled in this starter. It needs separate official Meta WhatsApp Business Cloud API setup, approved templates, server-side secrets, and scheduling. Costs may apply.

## Security notes
- This is a starter policy setup: any authenticated user in this Supabase project can read/write the shared register. Create accounts only for trusted church users; tighten policies before inviting more people.
- RLS is enabled on both tables. Never publish a Supabase secret/service-role key, WhatsApp token, private member CSV, or personal contact data in GitHub.
- This is separate from the existing Birthday Register Supabase project. Run the SQL only in the new `csi-whatsapp-centre` project.
