// Scheduled official WhatsApp Cloud API sender.
// Secrets are set in Supabase Edge Function secrets, never in the browser or GitHub.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret", "Access-Control-Allow-Methods": "POST, OPTIONS" };
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const expected = Deno.env.get("CRON_SECRET") || "";
  if (!expected || req.headers.get("x-cron-secret") !== expected) return json({ error: "Unauthorized" }, 401);
  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const waToken = Deno.env.get("WHATSAPP_ACCESS_TOKEN") || "";
  const phoneNumberId = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID") || "";
  const apiVersion = Deno.env.get("WHATSAPP_GRAPH_API_VERSION") || "v23.0";
  const birthdayTemplate = Deno.env.get("WHATSAPP_BIRTHDAY_TEMPLATE") || "";
  const anniversaryTemplate = Deno.env.get("WHATSAPP_ANNIVERSARY_TEMPLATE") || "";
  const languageCode = Deno.env.get("WHATSAPP_TEMPLATE_LANGUAGE") || "ta";
  if (!waToken || !phoneNumberId || !birthdayTemplate || !anniversaryTemplate) return json({ error: "Missing WhatsApp secrets or approved template names. No messages sent." }, 500);
  const db = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });
  // Church timezone: India Standard Time.
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const part = (type: string) => parts.find((p) => p.type === type)?.value || "00";
  const today = `${part("year")}-${part("month")}-${part("day")}`;
  const { data: members, error } = await db.from("church_contacts").select("id,name,phone,birthday,anniversary,whatsapp_consent,language").eq("whatsapp_consent", true);
  if (error) return json({ error: error.message }, 500);
  let sent = 0, skipped = 0, failed = 0;
  for (const c of members || []) {
    const items: Array<{type:"birthday"|"anniversary",date:string,template:string}> = [];
    if (c.birthday && c.birthday.slice(5) === today.slice(5)) items.push({type:"birthday",date:today,template:birthdayTemplate});
    if (c.anniversary && c.anniversary.slice(5) === today.slice(5)) items.push({type:"anniversary",date:today,template:anniversaryTemplate});
    for (const item of items) {
      const { data: prior } = await db.from("message_logs").select("id,status").eq("contact_id", c.id).eq("message_type", item.type).eq("occasion_date", today).maybeSingle();
      if (prior) { skipped++; continue; }
      try {
        const response = await fetch(`https://graph.facebook.com/${apiVersion}/${phoneNumberId}/messages`, {
          method: "POST", headers: { Authorization: `Bearer ${waToken}`, "Content-Type": "application/json" },
          body: JSON.stringify({ messaging_product: "whatsapp", recipient_type: "individual", to: c.phone, type: "template", template: { name: item.template, language: { code: languageCode }, components: [{ type: "body", parameters: [{ type: "text", text: c.name }] }] } })
        });
        const body = await response.json();
        if (!response.ok) {
          failed++;
          await db.from("message_logs").insert({contact_id:c.id,recipient_name:c.name,recipient_phone:c.phone,message_type:item.type,status:"failed",details:JSON.stringify(body).slice(0,1800),occasion_date:today});
        } else {
          sent++;
          await db.from("message_logs").insert({contact_id:c.id,recipient_name:c.name,recipient_phone:c.phone,message_type:item.type,status:"sent",details:"Accepted by WhatsApp Cloud API; delivery status may update separately.",provider_message_id:body.messages?.[0]?.id || null,occasion_date:today});
        }
      } catch (e) {
        failed++;
        await db.from("message_logs").insert({contact_id:c.id,recipient_name:c.name,recipient_phone:c.phone,message_type:item.type,status:"failed",details:String(e).slice(0,1800),occasion_date:today});
      }
    }
  }
  return json({ date: today, matched: members?.length || 0, sent, skipped, failed });
  function json(value: unknown, status = 200) { return new Response(JSON.stringify(value), { status, headers: { ...cors, "Content-Type": "application/json" } }); }
});
function json(value: unknown, status = 200) { return new Response(JSON.stringify(value), { status, headers: { ...cors, "Content-Type": "application/json" } }); }
