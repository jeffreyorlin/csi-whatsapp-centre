-- CSI Meetpar Yesu Alayam WhatsApp Automation Centre
-- Run this file in Supabase SQL Editor. Do not paste Markdown fences into SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.church_contacts (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  phone text not null check (phone ~ '^[0-9]{8,15}$'),
  birthday date,
  anniversary date,
  language text not null default 'ta' check (language in ('ta','en')),
  whatsapp_consent boolean not null default false,
  consent_recorded_at timestamptz,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null
);
create index if not exists church_contacts_phone_idx on public.church_contacts(phone);
create index if not exists church_contacts_birthday_idx on public.church_contacts(birthday);
create index if not exists church_contacts_anniversary_idx on public.church_contacts(anniversary);

create table if not exists public.message_logs (
  id uuid primary key default gen_random_uuid(),
  contact_id uuid references public.church_contacts(id) on delete set null,
  recipient_name text,
  recipient_phone text,
  message_type text not null check (message_type in ('birthday','anniversary','manual')),
  status text not null default 'queued' check (status in ('queued','sent','delivered','failed','skipped')),
  details text,
  provider_message_id text,
  occasion_date date,
  created_at timestamptz not null default now(),
  unique(contact_id, message_type, occasion_date)
);

alter table public.church_contacts enable row level security;
alter table public.message_logs enable row level security;
-- This starter lets signed-in church users share the same register.
-- Only invite trusted church users to this Supabase Auth project.
drop policy if exists "Signed-in users can read contacts" on public.church_contacts;
create policy "Signed-in users can read contacts" on public.church_contacts for select to authenticated using (true);
drop policy if exists "Signed-in users can add contacts" on public.church_contacts;
create policy "Signed-in users can add contacts" on public.church_contacts for insert to authenticated with check (true);
drop policy if exists "Signed-in users can update contacts" on public.church_contacts;
create policy "Signed-in users can update contacts" on public.church_contacts for update to authenticated using (true) with check (true);
drop policy if exists "Signed-in users can delete contacts" on public.church_contacts;
create policy "Signed-in users can delete contacts" on public.church_contacts for delete to authenticated using (true);
drop policy if exists "Signed-in users can read message logs" on public.message_logs;
create policy "Signed-in users can read message logs" on public.message_logs for select to authenticated using (true);
drop policy if exists "Signed-in users can insert message logs" on public.message_logs;
create policy "Signed-in users can insert message logs" on public.message_logs for insert to authenticated with check (true);

-- Optional consent timestamp helper: records when consent is checked on insert/update.
create or replace function public.set_consent_recorded_at()
returns trigger language plpgsql as $$
begin
  if new.whatsapp_consent = true and (tg_op = 'INSERT' or old.whatsapp_consent is distinct from true) then
    new.consent_recorded_at := now();
  elsif new.whatsapp_consent = false then
    new.consent_recorded_at := null;
  end if;
  return new;
end; $$;
drop trigger if exists church_contacts_consent_timestamp on public.church_contacts;
create trigger church_contacts_consent_timestamp before insert or update of whatsapp_consent on public.church_contacts for each row execute function public.set_consent_recorded_at();
